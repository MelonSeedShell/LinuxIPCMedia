/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */

#define __INTRINSIC_ONLYSPECIAL
#define __INTRINSIC_SPECIAL___readcr4 // Causes code generation in intrin-impl.h

#include <intrin.h>
